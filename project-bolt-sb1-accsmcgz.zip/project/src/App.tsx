import React, { useState } from 'react';
import LoginPage from './components/LoginPage';
import Dashboard from './components/Dashboard';
import CareerDetail from './components/CareerDetail';
import YouTubeChannels from './components/YouTubeChannels';
import AITools from './components/AITools';

export type Page = 'login' | 'dashboard' | 'career' | 'youtube' | 'ai-tools';

export interface User {
  username: string;
  loginId: string;
  collegeName: string;
}

function App() {
  const [currentPage, setCurrentPage] = useState<Page>('login');
  const [user, setUser] = useState<User | null>(null);
  const [selectedCareer, setSelectedCareer] = useState<string>('');

  const handleLogin = (userData: User) => {
    setUser(userData);
    setCurrentPage('dashboard');
  };

  const handleCareerSelect = (career: string) => {
    setSelectedCareer(career);
    setCurrentPage('career');
  };

  const handleLogout = () => {
    setUser(null);
    setCurrentPage('login');
  };

  const renderCurrentPage = () => {
    switch (currentPage) {
      case 'login':
        return <LoginPage onLogin={handleLogin} />;
      case 'dashboard':
        return (
          <Dashboard
            user={user!}
            onCareerSelect={handleCareerSelect}
            onNavigate={setCurrentPage}
            onLogout={handleLogout}
          />
        );
      case 'career':
        return (
          <CareerDetail
            career={selectedCareer}
            onBack={() => setCurrentPage('dashboard')}
            onNavigate={setCurrentPage}
          />
        );
      case 'youtube':
        return (
          <YouTubeChannels
            onBack={() => setCurrentPage('dashboard')}
            onNavigate={setCurrentPage}
          />
        );
      case 'ai-tools':
        return (
          <AITools
            onBack={() => setCurrentPage('dashboard')}
            onNavigate={setCurrentPage}
          />
        );
      default:
        return <LoginPage onLogin={handleLogin} />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      {renderCurrentPage()}
    </div>
  );
}

export default App;