import React from 'react';
import { ArrowLeft, Clock, Target, BookOpen } from 'lucide-react';
import { Page } from '../App';

interface LanguageDetailProps {
  language: string;
  onBack: () => void;
  onNavigate: (page: Page) => void;
}

const LanguageDetail: React.FC<LanguageDetailProps> = ({ language, onBack, onNavigate }) => {
  const getLanguageData = (lang: string) => {
    const data = {
      'C Programming': {
        uses: [
          'System Programming (Operating Systems, Device Drivers)',
          'Embedded Systems Development',
          'Microcontroller Programming',
          'Performance-Critical Applications',
          'Compiler Development',
          'Database Management Systems'
        ],
        mindMapUrl: 'https://images.pexels.com/photos/574071/pexels-photo-574071.jpeg?auto=compress&cs=tinysrgb&w=800',
        learningTime: '4-6 months',
        difficulty: 'Intermediate',
        description: 'C is a foundational programming language that provides low-level access to memory and system resources.'
      },
      'Java': {
        uses: [
          'Enterprise Web Applications',
          'Android Mobile Development',
          'Desktop GUI Applications',
          'Web Services and APIs',
          'Big Data Processing (Hadoop, Spark)',
          'Banking and Financial Services'
        ],
        mindMapUrl: 'https://images.pexels.com/photos/4164418/pexels-photo-4164418.jpeg?auto=compress&cs=tinysrgb&w=800',
        learningTime: '6-8 months',
        difficulty: 'Beginner to Intermediate',
        description: 'Java is a versatile, object-oriented language known for its "write once, run anywhere" philosophy.'
      },
      'Python': {
        uses: [
          'Data Science and Analytics',
          'Machine Learning and AI',
          'Web Development (Django, Flask)',
          'Automation and Scripting',
          'Scientific Computing',
          'Game Development'
        ],
        mindMapUrl: 'https://images.pexels.com/photos/1181671/pexels-photo-1181671.jpeg?auto=compress&cs=tinysrgb&w=800',
        learningTime: '3-5 months',
        difficulty: 'Beginner',
        description: 'Python is known for its simplicity and readability, making it perfect for beginners and rapid development.'
      },
      'C++': {
        uses: [
          'Game Development (Unreal Engine)',
          'High-Performance Applications',
          'System Software Development',
          'Real-time Systems',
          'Competitive Programming',
          'Graphics and Animation Software'
        ],
        mindMapUrl: 'https://images.pexels.com/photos/1148820/pexels-photo-1148820.jpeg?auto=compress&cs=tinysrgb&w=800',
        learningTime: '6-10 months',
        difficulty: 'Intermediate to Advanced',
        description: 'C++ extends C with object-oriented features, offering both low-level control and high-level abstractions.'
      },
      'Web Technology': {
        uses: [
          'Frontend Web Development',
          'Responsive Web Design',
          'Single Page Applications (SPAs)',
          'Progressive Web Apps (PWAs)',
          'Interactive User Interfaces',
          'E-commerce Websites'
        ],
        mindMapUrl: 'https://images.pexels.com/photos/196644/pexels-photo-196644.jpeg?auto=compress&cs=tinysrgb&w=800',
        learningTime: '4-7 months',
        difficulty: 'Beginner to Intermediate',
        description: 'Web technologies including HTML, CSS, and JavaScript form the foundation of modern web development.'
      },
      'SQL': {
        uses: [
          'Database Management and Queries',
          'Data Analysis and Reporting',
          'Business Intelligence',
          'Data Warehousing',
          'Backend Development',
          'Data Migration and ETL'
        ],
        mindMapUrl: 'https://images.pexels.com/photos/1181676/pexels-photo-1181676.jpeg?auto=compress&cs=tinysrgb&w=800',
        learningTime: '2-4 months',
        difficulty: 'Beginner',
        description: 'SQL is the standard language for managing and manipulating relational databases.'
      },
      'NoSQL': {
        uses: [
          'Big Data Applications',
          'Real-time Web Applications',
          'Content Management Systems',
          'Internet of Things (IoT)',
          'Social Media Platforms',
          'Mobile App Backends'
        ],
        mindMapUrl: 'https://images.pexels.com/photos/1181467/pexels-photo-1181467.jpeg?auto=compress&cs=tinysrgb&w=800',
        learningTime: '3-5 months',
        difficulty: 'Intermediate',
        description: 'NoSQL databases provide flexible, scalable solutions for modern application data storage needs.'
      }
    };
    return data[lang as keyof typeof data] || data['Python'];
  };

  const langData = getLanguageData(language);

  return (
    <div className="min-h-screen p-6">
      {/* Header */}
      <div className="flex items-center space-x-4 mb-8">
        <button
          onClick={onBack}
          className="p-3 bg-white/10 hover:bg-white/20 rounded-xl transition-all duration-300"
        >
          <ArrowLeft className="w-5 h-5 text-white" />
        </button>
        <div>
          <h1 className="text-4xl font-bold text-white">{language}</h1>
          <p className="text-gray-300 mt-2">{langData.description}</p>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="p-6 bg-white/10 backdrop-blur-lg rounded-2xl border border-white/20">
          <div className="flex items-center space-x-3">
            <Clock className="w-6 h-6 text-blue-400" />
            <div>
              <p className="text-white font-semibold">Learning Time</p>
              <p className="text-gray-300">{langData.learningTime}</p>
            </div>
          </div>
        </div>
        <div className="p-6 bg-white/10 backdrop-blur-lg rounded-2xl border border-white/20">
          <div className="flex items-center space-x-3">
            <Target className="w-6 h-6 text-green-400" />
            <div>
              <p className="text-white font-semibold">Difficulty</p>
              <p className="text-gray-300">{langData.difficulty}</p>
            </div>
          </div>
        </div>
        <div className="p-6 bg-white/10 backdrop-blur-lg rounded-2xl border border-white/20">
          <div className="flex items-center space-x-3">
            <BookOpen className="w-6 h-6 text-purple-400" />
            <div>
              <p className="text-white font-semibold">Applications</p>
              <p className="text-gray-300">{langData.uses.length} Major Uses</p>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Use Cases */}
        <div className="space-y-6">
          <h2 className="text-2xl font-bold text-white">Primary Applications</h2>
          <div className="space-y-4">
            {langData.uses.map((use, index) => (
              <div
                key={index}
                className="p-4 bg-white/10 backdrop-blur-lg rounded-xl border border-white/20 hover:border-white/40 transition-all duration-300"
              >
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white text-sm font-bold mt-1">
                    {index + 1}
                  </div>
                  <p className="text-white">{use}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Mind Map */}
        <div className="space-y-6">
          <h2 className="text-2xl font-bold text-white">Learning Mind Map</h2>
          <div className="bg-white/10 backdrop-blur-lg rounded-2xl border border-white/20 overflow-hidden">
            <img
              src={langData.mindMapUrl}
              alt={`${language} Mind Map`}
              className="w-full h-64 object-cover"
            />
            <div className="p-6">
              <h3 className="text-xl font-semibold text-white mb-2">Visual Learning Path</h3>
              <p className="text-gray-300 text-sm">
                This mind map represents the key concepts and learning progression for {language}. 
                Start from the basics and gradually work your way through advanced topics.
              </p>
            </div>
          </div>

          {/* Learning Timeline */}
          <div className="bg-white/10 backdrop-blur-lg rounded-2xl border border-white/20 p-6">
            <h3 className="text-xl font-semibold text-white mb-4">Suggested Learning Timeline</h3>
            <div className="space-y-3">
              <div className="flex items-center space-x-3">
                <div className="w-4 h-4 bg-green-500 rounded-full"></div>
                <span className="text-gray-300">Weeks 1-4: Fundamentals & Syntax</span>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-4 h-4 bg-yellow-500 rounded-full"></div>
                <span className="text-gray-300">Weeks 5-12: Core Concepts & Practice</span>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-4 h-4 bg-blue-500 rounded-full"></div>
                <span className="text-gray-300">Weeks 13+: Advanced Topics & Projects</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="mt-8 flex flex-col sm:flex-row gap-4">
        <button
          onClick={() => onNavigate('youtube')}
          className="px-8 py-4 bg-red-500 hover:bg-red-600 text-white font-semibold rounded-xl transition-all duration-300 transform hover:scale-105"
        >
          View YouTube Channels
        </button>
        <button
          onClick={() => onNavigate('ai-tools')}
          className="px-8 py-4 bg-violet-500 hover:bg-violet-600 text-white font-semibold rounded-xl transition-all duration-300 transform hover:scale-105"
        >
          Explore AI Tools
        </button>
      </div>
    </div>
  );
};

export default LanguageDetail;