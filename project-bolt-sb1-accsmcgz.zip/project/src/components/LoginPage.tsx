import React, { useState } from 'react';
import { User, BookOpen, Lock, User as UserIcon, GraduationCap } from 'lucide-react';

interface LoginPageProps {
  onLogin: (user: User) => void;
}

interface User {
  username: string;
  loginId: string;
  collegeName: string;
}

const LoginPage: React.FC<LoginPageProps> = ({ onLogin }) => {
  const [formData, setFormData] = useState({
    username: '',
    loginId: '',
    collegeName: '',
    password: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.username && formData.loginId && formData.collegeName && formData.password) {
      onLogin({
        username: formData.username,
        loginId: formData.loginId,
        collegeName: formData.collegeName
      });
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Background Image */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: 'url(https://images.pexels.com/photos/546819/pexels-photo-546819.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080&fit=crop)',
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-br from-blue-900/80 via-purple-900/85 to-slate-900/90"></div>
      </div>

      {/* 3D Information Hub Text */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <div className="text-center">
          <div 
            className="text-6xl md:text-8xl lg:text-9xl font-black text-transparent bg-gradient-to-r from-blue-400/30 to-purple-400/30 bg-clip-text mb-4"
            style={{
              textShadow: '0 0 60px rgba(59, 130, 246, 0.4), 0 0 120px rgba(139, 92, 246, 0.3)',
              transform: 'perspective(1000px) rotateX(10deg) rotateY(-5deg)',
              filter: 'drop-shadow(0 10px 20px rgba(0,0,0,0.3))'
            }}
          >
            INFORMATION
          </div>
          <div 
            className="text-6xl md:text-8xl lg:text-9xl font-black text-transparent bg-gradient-to-r from-purple-400/30 to-pink-400/30 bg-clip-text"
            style={{
              textShadow: '0 0 60px rgba(139, 92, 246, 0.4), 0 0 120px rgba(236, 72, 153, 0.3)',
              transform: 'perspective(1000px) rotateX(-10deg) rotateY(5deg)',
              filter: 'drop-shadow(0 10px 20px rgba(0,0,0,0.3))'
            }}
          >
            HUB
          </div>
        </div>
      </div>

      {/* Login Form - Positioned in bottom right */}
      <div className="relative z-10 min-h-screen flex items-end justify-end p-8">
        <div className="w-full max-w-sm">
          <div className="bg-white/5 backdrop-blur-md rounded-2xl p-6 shadow-2xl border border-white/10">
            <div className="text-center mb-6">
              <div className="flex justify-center mb-3">
                <div className="p-3 bg-gradient-to-br from-blue-500/20 to-purple-600/20 rounded-xl border border-white/20">
                  <BookOpen className="w-6 h-6 text-white" />
                </div>
              </div>
              <h1 className="text-2xl font-bold text-white mb-1">Welcome</h1>
              <p className="text-gray-300 text-sm">Access your tech career hub</p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="relative">
                <UserIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <input
                  type="text"
                  name="username"
                  placeholder="Username"
                  value={formData.username}
                  onChange={handleInputChange}
                  className="w-full pl-10 pr-4 py-3 bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-transparent transition-all duration-300 text-sm"
                  required
                />
              </div>

              <div className="relative">
                <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <input
                  type="text"
                  name="loginId"
                  placeholder="Login ID"
                  value={formData.loginId}
                  onChange={handleInputChange}
                  className="w-full pl-10 pr-4 py-3 bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-transparent transition-all duration-300 text-sm"
                  required
                />
              </div>

              <div className="relative">
                <GraduationCap className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <input
                  type="text"
                  name="collegeName"
                  placeholder="College Name"
                  value={formData.collegeName}
                  onChange={handleInputChange}
                  className="w-full pl-10 pr-4 py-3 bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-transparent transition-all duration-300 text-sm"
                  required
                />
              </div>

              <div className="relative">
                <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <input
                  type="password"
                  name="password"
                  placeholder="Password"
                  value={formData.password}
                  onChange={handleInputChange}
                  className="w-full pl-10 pr-4 py-3 bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-transparent transition-all duration-300 text-sm"
                  required
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-gradient-to-r from-blue-500/80 to-purple-600/80 text-white font-semibold rounded-lg hover:from-blue-600/90 hover:to-purple-700/90 transform hover:scale-105 transition-all duration-300 shadow-lg hover:shadow-xl backdrop-blur-sm"
              >
                Sign In
              </button>
            </form>

            <div className="mt-4 text-center">
              <p className="text-gray-400 text-xs">
                Your gateway to tech careers
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;