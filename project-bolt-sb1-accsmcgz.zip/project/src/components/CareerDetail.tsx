import React from 'react';
import { ArrowLeft, Clock, Target, BookOpen, DollarSign, TrendingUp, Users, Award } from 'lucide-react';
import { Page } from '../App';

interface CareerDetailProps {
  career: string;
  onBack: () => void;
  onNavigate: (page: Page) => void;
}

const CareerDetail: React.FC<CareerDetailProps> = ({ career, onBack, onNavigate }) => {
  const getCareerData = (careerName: string) => {
    const data = {
      'Cybersecurity': {
        description: 'Protect organizations from cyber threats and secure digital infrastructure',
        requirements: {
          programmingLanguages: ['Python', 'C/C++', 'JavaScript', 'PowerShell', 'Bash'],
          tools: ['Wireshark', 'Metasploit', 'Nmap', 'Burp Suite', 'Kali Linux', 'SIEM Tools'],
          courses: ['CompTIA Security+', 'CISSP', 'CEH', 'Network Security', 'Ethical Hacking'],
          platforms: ['TryHackMe', 'HackTheBox', 'Cybrary', 'SANS', 'Coursera']
        },
        moneyMaking: [
          'Bug Bounty Programs ($500-$50K per bug)',
          'Freelance Security Audits ($100-$300/hour)',
          'Security Consulting ($150-$500/hour)',
          'Teaching Cybersecurity Courses ($50-$200/hour)',
          'Creating Security Tools and Selling Licenses'
        ],
        difficulty: 'Hard',
        duration: '12-18 months',
        earning: '$80K - $150K',
        mindMapUrl: 'https://images.pexels.com/photos/60504/security-protection-anti-virus-software-60504.jpeg?auto=compress&cs=tinysrgb&w=800',
        difficultyLevel: 85,
        jobGrowth: '+31% (Much faster than average)'
      },
      'Mobile App Developer': {
        description: 'Create innovative mobile applications for iOS and Android platforms',
        requirements: {
          programmingLanguages: ['Swift', 'Kotlin', 'Java', 'Dart', 'JavaScript', 'React Native'],
          tools: ['Xcode', 'Android Studio', 'Flutter', 'React Native', 'Firebase', 'Git'],
          courses: ['iOS Development', 'Android Development', 'Flutter Course', 'UI/UX Design', 'Mobile Architecture'],
          platforms: ['Apple Developer', 'Google Play Console', 'Udemy', 'Codecademy', 'freeCodeCamp']
        },
        moneyMaking: [
          'App Store Revenue (Freemium/Paid apps)',
          'Freelance App Development ($50-$150/hour)',
          'In-App Purchases and Subscriptions',
          'Mobile App Consulting ($100-$250/hour)',
          'Creating and Selling App Templates'
        ],
        difficulty: 'Medium',
        duration: '8-12 months',
        earning: '$70K - $130K',
        mindMapUrl: 'https://images.pexels.com/photos/147413/twitter-facebook-together-exchange-of-information-147413.jpeg?auto=compress&cs=tinysrgb&w=800',
        difficultyLevel: 65,
        jobGrowth: '+22% (Much faster than average)'
      },
      'Web Developer': {
        description: 'Build responsive websites and web applications using modern technologies',
        requirements: {
          programmingLanguages: ['HTML', 'CSS', 'JavaScript', 'TypeScript', 'Python', 'PHP'],
          tools: ['VS Code', 'Git', 'Node.js', 'React', 'Vue.js', 'Docker', 'AWS'],
          courses: ['Full Stack Development', 'Frontend Frameworks', 'Backend Development', 'Database Design', 'DevOps'],
          platforms: ['GitHub', 'Netlify', 'Vercel', 'Heroku', 'freeCodeCamp', 'The Odin Project']
        },
        moneyMaking: [
          'Freelance Web Development ($30-$100/hour)',
          'Building and Selling Websites ($500-$10K)',
          'Creating Web Templates ($20-$200 each)',
          'Web Development Consulting ($75-$200/hour)',
          'Teaching Web Development Online'
        ],
        difficulty: 'Easy',
        duration: '6-10 months',
        earning: '$60K - $120K',
        mindMapUrl: 'https://images.pexels.com/photos/196644/pexels-photo-196644.jpeg?auto=compress&cs=tinysrgb&w=800',
        difficultyLevel: 45,
        jobGrowth: '+13% (Faster than average)'
      },
      'Game Developer': {
        description: 'Design and develop interactive games for various platforms',
        requirements: {
          programmingLanguages: ['C#', 'C++', 'JavaScript', 'Python', 'Lua', 'GDScript'],
          tools: ['Unity', 'Unreal Engine', 'Godot', 'Blender', 'Photoshop', 'Git'],
          courses: ['Game Design', 'Unity Development', 'Unreal Engine', '3D Modeling', 'Game Physics'],
          platforms: ['Unity Learn', 'Unreal Engine Documentation', 'GameDev.tv', 'Brackeys', 'itch.io']
        },
        moneyMaking: [
          'Publishing Games on Steam/Mobile Stores',
          'Freelance Game Development ($40-$120/hour)',
          'Creating Game Assets ($10-$500 per asset)',
          'Game Development Consulting ($100-$300/hour)',
          'Teaching Game Development'
        ],
        difficulty: 'Hard',
        duration: '10-15 months',
        earning: '$65K - $140K',
        mindMapUrl: 'https://images.pexels.com/photos/442576/pexels-photo-442576.jpeg?auto=compress&cs=tinysrgb&w=800',
        difficultyLevel: 80,
        jobGrowth: '+11% (Faster than average)'
      },
      'Software Engineer': {
        description: 'Design, develop, and maintain software systems and applications',
        requirements: {
          programmingLanguages: ['Java', 'Python', 'C++', 'JavaScript', 'Go', 'Rust'],
          tools: ['Git', 'Docker', 'Kubernetes', 'Jenkins', 'AWS', 'Linux'],
          courses: ['Data Structures & Algorithms', 'System Design', 'Software Architecture', 'DevOps', 'Cloud Computing'],
          platforms: ['LeetCode', 'HackerRank', 'GitHub', 'Stack Overflow', 'Coursera']
        },
        moneyMaking: [
          'High-paying Tech Jobs ($75K-$200K+)',
          'Freelance Software Development ($60-$200/hour)',
          'Creating SaaS Products',
          'Technical Consulting ($150-$400/hour)',
          'Open Source Contributions and Sponsorships'
        ],
        difficulty: 'Medium',
        duration: '8-14 months',
        earning: '$75K - $160K',
        mindMapUrl: 'https://images.pexels.com/photos/574071/pexels-photo-574071.jpeg?auto=compress&cs=tinysrgb&w=800',
        difficultyLevel: 70,
        jobGrowth: '+22% (Much faster than average)'
      },
      'Data Analyst': {
        description: 'Extract insights from data to help organizations make informed decisions',
        requirements: {
          programmingLanguages: ['Python', 'R', 'SQL', 'JavaScript', 'Scala'],
          tools: ['Excel', 'Tableau', 'Power BI', 'Jupyter', 'Pandas', 'NumPy'],
          courses: ['Statistics', 'Data Visualization', 'Machine Learning Basics', 'Business Intelligence', 'SQL'],
          platforms: ['Kaggle', 'DataCamp', 'Coursera', 'edX', 'Tableau Public']
        },
        moneyMaking: [
          'Freelance Data Analysis ($40-$100/hour)',
          'Creating Data Dashboards ($500-$5K)',
          'Data Consulting Services ($75-$200/hour)',
          'Selling Data Insights Reports',
          'Teaching Data Analysis Online'
        ],
        difficulty: 'Medium',
        duration: '6-12 months',
        earning: '$55K - $110K',
        mindMapUrl: 'https://images.pexels.com/photos/590022/pexels-photo-590022.jpeg?auto=compress&cs=tinysrgb&w=800',
        difficultyLevel: 60,
        jobGrowth: '+25% (Much faster than average)'
      },
      'AI/ML Engineer': {
        description: 'Develop artificial intelligence and machine learning solutions',
        requirements: {
          programmingLanguages: ['Python', 'R', 'Julia', 'C++', 'JavaScript'],
          tools: ['TensorFlow', 'PyTorch', 'Scikit-learn', 'Jupyter', 'Docker', 'MLflow'],
          courses: ['Machine Learning', 'Deep Learning', 'Neural Networks', 'Computer Vision', 'NLP'],
          platforms: ['Kaggle', 'Google Colab', 'Hugging Face', 'Papers with Code', 'Fast.ai']
        },
        moneyMaking: [
          'High-demand AI/ML Jobs ($90K-$200K+)',
          'AI Consulting ($200-$500/hour)',
          'Creating AI Products and APIs',
          'Kaggle Competitions (Prize money)',
          'AI Research and Publications'
        ],
        difficulty: 'Hard',
        duration: '12-20 months',
        earning: '$90K - $180K',
        mindMapUrl: 'https://images.pexels.com/photos/8386440/pexels-photo-8386440.jpeg?auto=compress&cs=tinysrgb&w=800',
        difficultyLevel: 90,
        jobGrowth: '+22% (Much faster than average)'
      },
      'Cloud Computing': {
        description: 'Design, implement, and manage cloud infrastructure and services',
        requirements: {
          programmingLanguages: ['Python', 'Go', 'JavaScript', 'PowerShell', 'Bash'],
          tools: ['AWS', 'Azure', 'GCP', 'Docker', 'Kubernetes', 'Terraform'],
          courses: ['AWS Solutions Architect', 'Azure Fundamentals', 'DevOps', 'Container Orchestration', 'Infrastructure as Code'],
          platforms: ['AWS Training', 'Microsoft Learn', 'Google Cloud Skills', 'A Cloud Guru', 'Linux Academy']
        },
        moneyMaking: [
          'Cloud Architecture Consulting ($150-$400/hour)',
          'Cloud Migration Services ($100-$300/hour)',
          'Creating Cloud Automation Tools',
          'Teaching Cloud Technologies',
          'Cloud Security Consulting'
        ],
        difficulty: 'Medium',
        duration: '8-14 months',
        earning: '$70K - $140K',
        mindMapUrl: 'https://images.pexels.com/photos/1181675/pexels-photo-1181675.jpeg?auto=compress&cs=tinysrgb&w=800',
        difficultyLevel: 65,
        jobGrowth: '+19% (Much faster than average)'
      },
      'Blockchain Developer': {
        description: 'Build decentralized applications and smart contracts on blockchain platforms',
        requirements: {
          programmingLanguages: ['Solidity', 'JavaScript', 'Python', 'Go', 'Rust'],
          tools: ['Truffle', 'Hardhat', 'MetaMask', 'Web3.js', 'Ganache', 'IPFS'],
          courses: ['Blockchain Fundamentals', 'Smart Contract Development', 'DeFi', 'NFTs', 'Cryptocurrency'],
          platforms: ['Ethereum', 'Polygon', 'Binance Smart Chain', 'CryptoZombies', 'Buildspace']
        },
        moneyMaking: [
          'DeFi Protocol Development ($100-$300/hour)',
          'NFT Marketplace Creation',
          'Smart Contract Auditing ($200-$500/hour)',
          'Blockchain Consulting ($150-$400/hour)',
          'Creating and Launching Tokens'
        ],
        difficulty: 'Hard',
        duration: '10-16 months',
        earning: '$80K - $170K',
        mindMapUrl: 'https://images.pexels.com/photos/844124/pexels-photo-844124.jpeg?auto=compress&cs=tinysrgb&w=800',
        difficultyLevel: 85,
        jobGrowth: '+87% (Much faster than average)'
      }
    };
    return data[careerName as keyof typeof data] || data['Web Developer'];
  };

  const careerData = getCareerData(career);

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'Easy': return 'text-green-400';
      case 'Medium': return 'text-yellow-400';
      case 'Hard': return 'text-red-400';
      default: return 'text-gray-400';
    }
  };

  return (
    <div className="min-h-screen p-6">
      {/* Header */}
      <div className="flex items-center space-x-4 mb-8">
        <button
          onClick={onBack}
          className="p-3 bg-white/10 hover:bg-white/20 rounded-xl transition-all duration-300"
        >
          <ArrowLeft className="w-5 h-5 text-white" />
        </button>
        <div>
          <h1 className="text-4xl font-bold text-white">{career}</h1>
          <p className="text-gray-300 mt-2">{careerData.description}</p>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <div className="p-6 bg-white/10 backdrop-blur-lg rounded-2xl border border-white/20">
          <div className="flex items-center space-x-3">
            <Clock className="w-6 h-6 text-blue-400" />
            <div>
              <p className="text-white font-semibold">Duration</p>
              <p className="text-gray-300">{careerData.duration}</p>
            </div>
          </div>
        </div>
        <div className="p-6 bg-white/10 backdrop-blur-lg rounded-2xl border border-white/20">
          <div className="flex items-center space-x-3">
            <Target className={`w-6 h-6 ${getDifficultyColor(careerData.difficulty)}`} />
            <div>
              <p className="text-white font-semibold">Difficulty</p>
              <p className="text-gray-300">{careerData.difficulty}</p>
            </div>
          </div>
        </div>
        <div className="p-6 bg-white/10 backdrop-blur-lg rounded-2xl border border-white/20">
          <div className="flex items-center space-x-3">
            <DollarSign className="w-6 h-6 text-green-400" />
            <div>
              <p className="text-white font-semibold">Earning</p>
              <p className="text-gray-300">{careerData.earning}</p>
            </div>
          </div>
        </div>
        <div className="p-6 bg-white/10 backdrop-blur-lg rounded-2xl border border-white/20">
          <div className="flex items-center space-x-3">
            <TrendingUp className="w-6 h-6 text-purple-400" />
            <div>
              <p className="text-white font-semibold">Job Growth</p>
              <p className="text-gray-300">{careerData.jobGrowth}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
        {/* Requirements */}
        <div className="space-y-6">
          <h2 className="text-2xl font-bold text-white">Requirements & Skills</h2>
          
          <div className="bg-white/10 backdrop-blur-lg rounded-2xl border border-white/20 p-6">
            <h3 className="text-lg font-semibold text-white mb-4">Programming Languages</h3>
            <div className="flex flex-wrap gap-2">
              {careerData.requirements.programmingLanguages.map((lang, index) => (
                <span key={index} className="px-3 py-1 bg-blue-500/20 text-blue-300 rounded-full text-sm">
                  {lang}
                </span>
              ))}
            </div>
          </div>

          <div className="bg-white/10 backdrop-blur-lg rounded-2xl border border-white/20 p-6">
            <h3 className="text-lg font-semibold text-white mb-4">Tools & Technologies</h3>
            <div className="flex flex-wrap gap-2">
              {careerData.requirements.tools.map((tool, index) => (
                <span key={index} className="px-3 py-1 bg-purple-500/20 text-purple-300 rounded-full text-sm">
                  {tool}
                </span>
              ))}
            </div>
          </div>

          <div className="bg-white/10 backdrop-blur-lg rounded-2xl border border-white/20 p-6">
            <h3 className="text-lg font-semibold text-white mb-4">Recommended Courses</h3>
            <div className="space-y-2">
              {careerData.requirements.courses.map((course, index) => (
                <div key={index} className="flex items-center space-x-3">
                  <BookOpen className="w-4 h-4 text-green-400" />
                  <span className="text-gray-300">{course}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white/10 backdrop-blur-lg rounded-2xl border border-white/20 p-6">
            <h3 className="text-lg font-semibold text-white mb-4">Learning Platforms</h3>
            <div className="flex flex-wrap gap-2">
              {careerData.requirements.platforms.map((platform, index) => (
                <span key={index} className="px-3 py-1 bg-teal-500/20 text-teal-300 rounded-full text-sm">
                  {platform}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Mind Map & Difficulty */}
        <div className="space-y-6">
          <h2 className="text-2xl font-bold text-white">Learning Path & Difficulty</h2>
          
          <div className="bg-white/10 backdrop-blur-lg rounded-2xl border border-white/20 overflow-hidden">
            <img
              src={careerData.mindMapUrl}
              alt={`${career} Mind Map`}
              className="w-full h-48 object-cover"
            />
            <div className="p-6">
              <h3 className="text-xl font-semibold text-white mb-2">Learning Mind Map</h3>
              <p className="text-gray-300 text-sm">
                Visual representation of key concepts and skills needed for {career}.
              </p>
            </div>
          </div>

          <div className="bg-white/10 backdrop-blur-lg rounded-2xl border border-white/20 p-6">
            <h3 className="text-lg font-semibold text-white mb-4">Difficulty Level</h3>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-gray-300">Overall Difficulty</span>
                <span className={`font-semibold ${getDifficultyColor(careerData.difficulty)}`}>
                  {careerData.difficultyLevel}/100
                </span>
              </div>
              <div className="w-full bg-gray-700 rounded-full h-3">
                <div 
                  className={`h-3 rounded-full ${
                    careerData.difficulty === 'Easy' ? 'bg-green-500' :
                    careerData.difficulty === 'Medium' ? 'bg-yellow-500' : 'bg-red-500'
                  }`}
                  style={{ width: `${careerData.difficultyLevel}%` }}
                ></div>
              </div>
            </div>
          </div>

          <div className="bg-white/10 backdrop-blur-lg rounded-2xl border border-white/20 p-6">
            <h3 className="text-lg font-semibold text-white mb-4">Learning Timeline</h3>
            <div className="space-y-3">
              <div className="flex items-center space-x-3">
                <div className="w-4 h-4 bg-green-500 rounded-full"></div>
                <span className="text-gray-300">Months 1-3: Fundamentals</span>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-4 h-4 bg-yellow-500 rounded-full"></div>
                <span className="text-gray-300">Months 4-8: Core Skills</span>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-4 h-4 bg-blue-500 rounded-full"></div>
                <span className="text-gray-300">Months 9+: Advanced & Projects</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Money Making Opportunities */}
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-white mb-6">💰 Money Making Opportunities as a Student</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {careerData.moneyMaking.map((opportunity, index) => (
            <div
              key={index}
              className="p-6 bg-gradient-to-br from-green-500/20 to-emerald-500/20 rounded-2xl border border-green-500/30"
            >
              <div className="flex items-start space-x-3">
                <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center text-white text-sm font-bold mt-1">
                  {index + 1}
                </div>
                <p className="text-white font-medium">{opportunity}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex flex-col sm:flex-row gap-4">
        <button
          onClick={() => onNavigate('youtube')}
          className="px-8 py-4 bg-red-500 hover:bg-red-600 text-white font-semibold rounded-xl transition-all duration-300 transform hover:scale-105"
        >
          View Learning Channels
        </button>
        <button
          onClick={() => onNavigate('ai-tools')}
          className="px-8 py-4 bg-violet-500 hover:bg-violet-600 text-white font-semibold rounded-xl transition-all duration-300 transform hover:scale-105"
        >
          Explore AI Tools
        </button>
      </div>
    </div>
  );
};

export default CareerDetail;