import React from 'react';
import { ArrowLeft, Bot, ExternalLink, Sparkles } from 'lucide-react';
import { Page } from '../App';

interface AIToolsProps {
  onBack: () => void;
  onNavigate: (page: Page) => void;
}

const AITools: React.FC<AIToolsProps> = ({ onBack, onNavigate }) => {
  const aiTools = [
    {
      name: 'ChatGPT',
      description: 'Advanced AI assistant for coding help, debugging, and learning concepts',
      category: 'General AI',
      features: ['Code generation', 'Bug fixing', 'Concept explanation', 'Project ideas'],
      color: 'from-green-500 to-green-600',
      studentUse: 'Get instant help with coding problems and explanations'
    },
    {
      name: 'GitHub Copilot',
      description: 'AI pair programmer that suggests code completions in real-time',
      category: 'Code Assistant',
      features: ['Code completion', 'Function generation', 'Comment-to-code', 'Multi-language'],
      color: 'from-purple-500 to-purple-600',
      studentUse: 'Speed up coding assignments and learn best practices'
    },
    {
      name: 'Replit Ghostwriter',
      description: 'AI coding assistant integrated into the Replit online IDE',
      category: 'IDE Integration',
      features: ['Code suggestions', 'Error detection', 'Code explanation', 'Refactoring'],
      color: 'from-blue-500 to-blue-600',
      studentUse: 'Code directly in browser with AI assistance'
    },
    {
      name: 'Claude',
      description: 'AI assistant excellent at code analysis and technical explanations',
      category: 'Code Analysis',
      features: ['Code review', 'Architecture advice', 'Best practices', 'Debugging'],
      color: 'from-violet-500 to-violet-600',
      studentUse: 'Get detailed code reviews and improvement suggestions'
    },
    {
      name: 'Phind',
      description: 'AI search engine optimized for developers and technical queries',
      category: 'Search Engine',
      features: ['Code search', 'Technical Q&A', 'Documentation', 'Stack Overflow integration'],
      color: 'from-cyan-500 to-cyan-600',
      studentUse: 'Find solutions to specific programming problems quickly'
    },
    {
      name: 'Codeium',
      description: 'Free AI-powered code acceleration toolkit',
      category: 'Free Tool',
      features: ['Code completion', 'Chat interface', 'Search', 'Multi-language'],
      color: 'from-orange-500 to-orange-600',
      studentUse: 'Free alternative to paid coding assistants'
    },
    {
      name: 'Cursor',
      description: 'AI-powered code editor built for productivity',
      category: 'Code Editor',
      features: ['AI chat', 'Code generation', 'Refactoring', 'Bug fixing'],
      color: 'from-indigo-500 to-indigo-600',
      studentUse: 'Complete coding environment with built-in AI'
    },
    {
      name: 'Perplexity AI',
      description: 'AI-powered research assistant for technical topics',
      category: 'Research',
      features: ['Technical research', 'Source citations', 'Real-time info', 'Academic papers'],
      color: 'from-teal-500 to-teal-600',
      studentUse: 'Research new technologies and concepts with citations'
    }
  ];

  const studyTips = [
    {
      title: 'Code Practice',
      description: 'Use AI to generate practice problems and solutions',
      icon: '💻',
      tip: 'Ask AI to create coding challenges based on your current skill level'
    },
    {
      title: 'Concept Learning',
      description: 'Ask AI to explain complex programming concepts',
      icon: '🧠',
      tip: 'Request explanations with examples and analogies for better understanding'
    },
    {
      title: 'Project Ideas',
      description: 'Get AI-generated project suggestions for your skill level',
      icon: '💡',
      tip: 'Ask for projects that match your career goals and current abilities'
    },
    {
      title: 'Code Review',
      description: 'Have AI review and improve your code quality',
      icon: '🔍',
      tip: 'Submit your code for feedback on performance, readability, and best practices'
    }
  ];

  const moneyMakingTips = [
    {
      title: 'Freelance with AI',
      description: 'Use AI tools to deliver projects faster and take on more clients',
      earning: '$20-100/hour',
      icon: '💼'
    },
    {
      title: 'Create AI-Powered Tools',
      description: 'Build and sell applications that integrate AI capabilities',
      earning: '$500-5000/month',
      icon: '🛠️'
    },
    {
      title: 'AI Tutoring',
      description: 'Teach others how to use AI tools effectively for programming',
      earning: '$30-80/hour',
      icon: '👨‍🏫'
    },
    {
      title: 'Content Creation',
      description: 'Create tutorials and courses about AI-assisted programming',
      earning: '$100-2000/month',
      icon: '📹'
    }
  ];

  return (
    <div className="min-h-screen p-6">
      {/* Header */}
      <div className="flex items-center space-x-4 mb-8">
        <button
          onClick={onBack}
          className="p-3 bg-white/10 hover:bg-white/20 rounded-xl transition-all duration-300"
        >
          <ArrowLeft className="w-5 h-5 text-white" />
        </button>
        <div>
          <h1 className="text-4xl font-bold text-white">AI Learning Tools</h1>
          <p className="text-gray-300 mt-2">Supercharge your tech career with AI</p>
        </div>
      </div>

      {/* Study Tips */}
      <div className="mb-12">
        <h2 className="text-2xl font-bold text-white mb-6">How AI Can Accelerate Your Learning</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {studyTips.map((tip, index) => (
            <div
              key={index}
              className="p-6 bg-gradient-to-br from-violet-500/20 to-purple-500/20 rounded-2xl border border-violet-500/30"
            >
              <div className="text-3xl mb-3">{tip.icon}</div>
              <h3 className="text-lg font-semibold text-white mb-2">{tip.title}</h3>
              <p className="text-gray-300 text-sm mb-3">{tip.description}</p>
              <p className="text-violet-300 text-xs italic">{tip.tip}</p>
            </div>
          ))}
        </div>
      </div>

      {/* AI Tools Grid */}
      <div className="mb-12">
        <h2 className="text-2xl font-bold text-white mb-6">Essential AI Tools for Students</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {aiTools.map((tool, index) => (
            <div
              key={index}
              className="group p-6 bg-white/10 backdrop-blur-lg rounded-2xl border border-white/20 hover:border-violet-500/50 transition-all duration-300 hover:transform hover:scale-105"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center space-x-3">
                  <div className={`w-12 h-12 bg-gradient-to-br ${tool.color} rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform`}>
                    <Bot className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold text-white">{tool.name}</h3>
                    <span className="text-xs px-2 py-1 bg-violet-500/20 text-violet-300 rounded-full">
                      {tool.category}
                    </span>
                  </div>
                </div>
                <ExternalLink className="w-5 h-5 text-gray-400 group-hover:text-violet-400 transition-colors" />
              </div>
              
              <p className="text-gray-300 text-sm leading-relaxed mb-3">
                {tool.description}
              </p>
              
              <div className="mb-4 p-3 bg-blue-500/10 rounded-lg border border-blue-500/20">
                <p className="text-blue-300 text-sm font-medium">Student Use Case:</p>
                <p className="text-blue-200 text-sm">{tool.studentUse}</p>
              </div>
              
              <div className="space-y-2">
                <h4 className="text-white font-medium text-sm">Key Features:</h4>
                <div className="flex flex-wrap gap-2">
                  {tool.features.map((feature, featureIndex) => (
                    <span
                      key={featureIndex}
                      className="text-xs px-2 py-1 bg-white/10 text-gray-300 rounded-full"
                    >
                      {feature}
                    </span>
                  ))}
                </div>
              </div>
              
              <button className="mt-4 w-full py-2 bg-violet-500/20 hover:bg-violet-500/30 text-violet-300 hover:text-violet-200 font-medium rounded-lg transition-all duration-300">
                Explore Tool
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Money Making with AI */}
      <div className="mb-12">
        <h2 className="text-2xl font-bold text-white mb-6">💰 Make Money with AI as a Student</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {moneyMakingTips.map((tip, index) => (
            <div
              key={index}
              className="p-6 bg-gradient-to-br from-green-500/20 to-emerald-500/20 rounded-2xl border border-green-500/30"
            >
              <div className="flex items-start space-x-4">
                <div className="text-3xl">{tip.icon}</div>
                <div className="flex-1">
                  <h3 className="text-lg font-semibold text-white mb-2">{tip.title}</h3>
                  <p className="text-gray-300 text-sm mb-3">{tip.description}</p>
                  <div className="flex items-center justify-between">
                    <span className="text-green-400 font-semibold text-sm">Potential: {tip.earning}</span>
                    <span className="text-xs px-2 py-1 bg-green-500/20 text-green-300 rounded-full">
                      Student Friendly
                    </span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Best Practices */}
      <div className="mb-8 p-8 bg-gradient-to-r from-blue-500/20 to-violet-500/20 rounded-2xl border border-blue-500/30">
        <div className="flex items-center space-x-3 mb-6">
          <Sparkles className="w-8 h-8 text-yellow-400" />
          <h2 className="text-2xl font-bold text-white">AI Learning Best Practices</h2>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div>
            <h3 className="text-lg font-semibold text-white mb-4">✅ Do's</h3>
            <ul className="space-y-2 text-gray-300">
              <li>• Ask specific, detailed questions</li>
              <li>• Provide context for your coding problems</li>
              <li>• Use AI to explain unfamiliar concepts</li>
              <li>• Verify AI-generated code before using</li>
              <li>• Practice coding without AI assistance</li>
              <li>• Use AI to generate practice problems</li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold text-white mb-4">❌ Don'ts</h3>
            <ul className="space-y-2 text-gray-300">
              <li>• Don't rely solely on AI for learning</li>
              <li>• Don't copy code without understanding</li>
              <li>• Don't skip manual practice and problem-solving</li>
              <li>• Don't trust AI output blindly</li>
              <li>• Don't ignore fundamental concepts</li>
              <li>• Don't use AI for academic dishonesty</li>
            </ul>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <div className="flex flex-col sm:flex-row gap-4">
        <button
          onClick={() => onNavigate('dashboard')}
          className="px-8 py-4 bg-blue-500 hover:bg-blue-600 text-white font-semibold rounded-xl transition-all duration-300 transform hover:scale-105"
        >
          Back to Dashboard
        </button>
        <button
          onClick={() => onNavigate('youtube')}
          className="px-8 py-4 bg-red-500 hover:bg-red-600 text-white font-semibold rounded-xl transition-all duration-300 transform hover:scale-105"
        >
          View Learning Channels
        </button>
      </div>
    </div>
  );
};

export default AITools;