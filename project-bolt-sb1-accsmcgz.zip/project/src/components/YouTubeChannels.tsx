import React from 'react';
import { ArrowLeft, Youtube, ExternalLink } from 'lucide-react';
import { Page } from '../App';

interface YouTubeChannelsProps {
  onBack: () => void;
  onNavigate: (page: Page) => void;
}

const YouTubeChannels: React.FC<YouTubeChannelsProps> = ({ onBack, onNavigate }) => {
  const channelsByCareer = {
    'Cybersecurity': [
      { name: 'NetworkChuck', description: 'Cybersecurity, networking, and ethical hacking tutorials', subscribers: '2.1M' },
      { name: 'John Hammond', description: 'Malware analysis, CTFs, and cybersecurity challenges', subscribers: '500K' },
      { name: 'The Cyber Mentor', description: 'Ethical hacking and penetration testing', subscribers: '300K' },
      { name: 'Professor Messer', description: 'CompTIA Security+ and IT certification prep', subscribers: '1.2M' }
    ],
    'Mobile App Developer': [
      { name: 'CodeWithChris', description: 'iOS development with Swift and SwiftUI', subscribers: '300K' },
      { name: 'Philipp Lackner', description: 'Android development with Kotlin', subscribers: '200K' },
      { name: 'Flutter', description: 'Official Flutter channel for cross-platform development', subscribers: '500K' },
      { name: 'Traversy Media', description: 'React Native and mobile development tutorials', subscribers: '2M' }
    ],
    'Web Developer': [
      { name: 'Traversy Media', description: 'Full-stack web development tutorials', subscribers: '2M' },
      { name: 'Web Dev Simplified', description: 'Modern web development made easy', subscribers: '1.1M' },
      { name: 'The Net Ninja', description: 'Frontend and backend web technologies', subscribers: '1.1M' },
      { name: 'Kevin Powell', description: 'CSS specialist with amazing tutorials', subscribers: '800K' }
    ],
    'Game Developer': [
      { name: 'Brackeys', description: 'Unity game development tutorials', subscribers: '1.6M' },
      { name: 'Code Monkey', description: 'Unity tutorials and game development tips', subscribers: '400K' },
      { name: 'Unreal Engine', description: 'Official Unreal Engine tutorials', subscribers: '1M' },
      { name: 'GameMaker', description: 'GameMaker Studio tutorials and tips', subscribers: '100K' }
    ],
    'Software Engineer': [
      { name: 'Tech With Tim', description: 'Programming tutorials and software engineering', subscribers: '1.2M' },
      { name: 'Coding Train', description: 'Creative coding and programming challenges', subscribers: '1.5M' },
      { name: 'CS Dojo', description: 'Programming fundamentals and career advice', subscribers: '1.8M' },
      { name: 'Derek Banas', description: 'Programming language tutorials', subscribers: '1.1M' }
    ],
    'Data Analyst': [
      { name: 'Alex The Analyst', description: 'Data analysis with SQL, Python, and Tableau', subscribers: '500K' },
      { name: 'Ken Jee', description: 'Data science career advice and projects', subscribers: '300K' },
      { name: 'Luke Barousse', description: 'Data analyst career guidance and SQL tutorials', subscribers: '200K' },
      { name: 'ExcelIsFun', description: 'Advanced Excel techniques for data analysis', subscribers: '800K' }
    ],
    'AI/ML Engineer': [
      { name: '3Blue1Brown', description: 'Mathematical concepts behind machine learning', subscribers: '4.8M' },
      { name: 'Two Minute Papers', description: 'Latest AI research explained simply', subscribers: '1.3M' },
      { name: 'Sentdex', description: 'Python programming for AI and machine learning', subscribers: '1.2M' },
      { name: 'Andrew Ng', description: 'Machine learning courses and lectures', subscribers: '800K' }
    ],
    'Cloud Computing': [
      { name: 'A Cloud Guru', description: 'AWS, Azure, and GCP certification training', subscribers: '500K' },
      { name: 'TechWorld with Nana', description: 'DevOps and cloud technologies', subscribers: '900K' },
      { name: 'AWS', description: 'Official Amazon Web Services tutorials', subscribers: '300K' },
      { name: 'Microsoft Azure', description: 'Official Microsoft Azure content', subscribers: '200K' }
    ],
    'Blockchain Developer': [
      { name: 'Dapp University', description: 'Blockchain development and smart contracts', subscribers: '300K' },
      { name: 'EatTheBlocks', description: 'Solidity and DeFi development tutorials', subscribers: '100K' },
      { name: 'Moralis Web3', description: 'Web3 development and blockchain tutorials', subscribers: '150K' },
      { name: 'Patrick Collins', description: 'Smart contract development and DeFi', subscribers: '200K' }
    ]
  };

  return (
    <div className="min-h-screen p-6">
      {/* Header */}
      <div className="flex items-center space-x-4 mb-8">
        <button
          onClick={onBack}
          className="p-3 bg-white/10 hover:bg-white/20 rounded-xl transition-all duration-300"
        >
          <ArrowLeft className="w-5 h-5 text-white" />
        </button>
        <div>
          <h1 className="text-4xl font-bold text-white">YouTube Learning Channels</h1>
          <p className="text-gray-300 mt-2">Curated channels for each tech career path</p>
        </div>
      </div>

      {/* Channels by Career */}
      <div className="space-y-8">
        {Object.entries(channelsByCareer).map(([career, channels]) => (
          <div key={career}>
            <h2 className="text-2xl font-bold text-white mb-6 flex items-center space-x-3">
              <div className="w-8 h-8 bg-gradient-to-br from-red-500 to-red-600 rounded-lg flex items-center justify-center">
                <Youtube className="w-5 h-5 text-white" />
              </div>
              <span>{career}</span>
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {channels.map((channel, index) => (
                <div
                  key={index}
                  className="group p-6 bg-white/10 backdrop-blur-lg rounded-2xl border border-white/20 hover:border-red-500/50 transition-all duration-300 hover:transform hover:scale-105"
                >
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center space-x-3">
                      <div className="w-12 h-12 bg-red-500 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform">
                        <Youtube className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <h3 className="text-xl font-semibold text-white">{channel.name}</h3>
                        <p className="text-red-400 text-sm">{channel.subscribers} subscribers</p>
                      </div>
                    </div>
                    <ExternalLink className="w-5 h-5 text-gray-400 group-hover:text-red-400 transition-colors" />
                  </div>
                  
                  <p className="text-gray-300 text-sm leading-relaxed mb-4">
                    {channel.description}
                  </p>
                  
                  <div className="flex items-center justify-between">
                    <span className="text-xs px-3 py-1 bg-red-500/20 text-red-300 rounded-full">
                      {career}
                    </span>
                    <button className="text-red-400 hover:text-red-300 text-sm font-medium transition-colors">
                      Visit Channel →
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* Additional Resources */}
      <div className="mt-12 p-8 bg-gradient-to-r from-red-500/20 to-pink-500/20 rounded-2xl border border-red-500/30">
        <h2 className="text-2xl font-bold text-white mb-4">Pro Tips for Learning</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h3 className="text-lg font-semibold text-white mb-2">📚 Study Strategy</h3>
            <ul className="text-gray-300 text-sm space-y-1">
              <li>• Follow along with code examples</li>
              <li>• Take notes on key concepts</li>
              <li>• Practice exercises regularly</li>
              <li>• Join channel communities</li>
            </ul>
          </div>
          <div>
            <h3 className="text-lg font-semibold text-white mb-2">⚡ Efficiency Tips</h3>
            <ul className="text-gray-300 text-sm space-y-1">
              <li>• Use playback speed controls</li>
              <li>• Create playlists for topics</li>
              <li>• Subscribe to notifications</li>
              <li>• Engage with comments</li>
            </ul>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <div className="mt-8 flex flex-col sm:flex-row gap-4">
        <button
          onClick={() => onNavigate('dashboard')}
          className="px-8 py-4 bg-blue-500 hover:bg-blue-600 text-white font-semibold rounded-xl transition-all duration-300 transform hover:scale-105"
        >
          Back to Dashboard
        </button>
        <button
          onClick={() => onNavigate('ai-tools')}
          className="px-8 py-4 bg-violet-500 hover:bg-violet-600 text-white font-semibold rounded-xl transition-all duration-300 transform hover:scale-105"
        >
          Explore AI Tools
        </button>
      </div>
    </div>
  );
};

export default YouTubeChannels;