import React from 'react';
import { User, LogOut, Youtube, Bot, Code, Database, Globe, Cpu, Smartphone, Shield, Cloud, Brain, Gamepad2, BarChart3, Blocks } from 'lucide-react';
import { Page } from '../App';

interface DashboardProps {
  user: User;
  onCareerSelect: (career: string) => void;
  onNavigate: (page: Page) => void;
  onLogout: () => void;
}

interface User {
  username: string;
  loginId: string;
  collegeName: string;
}

const Dashboard: React.FC<DashboardProps> = ({ user, onCareerSelect, onNavigate, onLogout }) => {
  const techCareers = [
    {
      name: 'Cybersecurity',
      description: 'Protect digital assets and fight cyber threats',
      icon: Shield,
      color: 'from-red-500 to-red-600',
      category: 'Security',
      difficulty: 'Hard',
      duration: '12-18 months',
      earning: '$80K - $150K'
    },
    {
      name: 'Mobile App Developer',
      description: 'Create iOS and Android applications',
      icon: Smartphone,
      color: 'from-green-500 to-green-600',
      category: 'Development',
      difficulty: 'Medium',
      duration: '8-12 months',
      earning: '$70K - $130K'
    },
    {
      name: 'Web Developer',
      description: 'Build modern websites and web applications',
      icon: Globe,
      color: 'from-blue-500 to-blue-600',
      category: 'Development',
      difficulty: 'Easy',
      duration: '6-10 months',
      earning: '$60K - $120K'
    },
    {
      name: 'Game Developer',
      description: 'Design and develop interactive games',
      icon: Gamepad2,
      color: 'from-purple-500 to-purple-600',
      category: 'Development',
      difficulty: 'Hard',
      duration: '10-15 months',
      earning: '$65K - $140K'
    },
    {
      name: 'Software Engineer',
      description: 'Build scalable software systems and applications',
      icon: Code,
      color: 'from-indigo-500 to-indigo-600',
      category: 'Engineering',
      difficulty: 'Medium',
      duration: '8-14 months',
      earning: '$75K - $160K'
    },
    {
      name: 'Data Analyst',
      description: 'Extract insights from data to drive decisions',
      icon: BarChart3,
      color: 'from-teal-500 to-teal-600',
      category: 'Analytics',
      difficulty: 'Medium',
      duration: '6-12 months',
      earning: '$55K - $110K'
    },
    {
      name: 'AI/ML Engineer',
      description: 'Develop artificial intelligence and machine learning solutions',
      icon: Brain,
      color: 'from-pink-500 to-pink-600',
      category: 'AI/ML',
      difficulty: 'Hard',
      duration: '12-20 months',
      earning: '$90K - $180K'
    },
    {
      name: 'Cloud Computing',
      description: 'Design and manage cloud infrastructure',
      icon: Cloud,
      color: 'from-cyan-500 to-cyan-600',
      category: 'Infrastructure',
      difficulty: 'Medium',
      duration: '8-14 months',
      earning: '$70K - $140K'
    },
    {
      name: 'Blockchain Developer',
      description: 'Build decentralized applications and smart contracts',
      icon: Blocks,
      color: 'from-orange-500 to-orange-600',
      category: 'Blockchain',
      difficulty: 'Hard',
      duration: '10-16 months',
      earning: '$80K - $170K'
    }
  ];

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'Easy': return 'text-green-400 bg-green-500/20';
      case 'Medium': return 'text-yellow-400 bg-yellow-500/20';
      case 'Hard': return 'text-red-400 bg-red-500/20';
      default: return 'text-gray-400 bg-gray-500/20';
    }
  };

  return (
    <div className="min-h-screen p-6">
      {/* Header */}
      <header className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-4xl font-bold text-white mb-2">Information Hub</h1>
          <p className="text-gray-300">Welcome back, {user.username} - Explore Tech Careers</p>
        </div>
        <div className="flex items-center space-x-4">
          <div className="text-right text-white">
            <p className="font-semibold">{user.username}</p>
            <p className="text-sm text-gray-300">{user.collegeName}</p>
          </div>
          <button
            onClick={onLogout}
            className="p-3 bg-red-500/20 hover:bg-red-500/30 rounded-xl transition-all duration-300"
          >
            <LogOut className="w-5 h-5 text-red-400" />
          </button>
        </div>
      </header>

      {/* Quick Navigation */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
        <button
          onClick={() => onNavigate('youtube')}
          className="p-6 bg-red-500/20 hover:bg-red-500/30 rounded-2xl transition-all duration-300 text-left group"
        >
          <div className="flex items-center space-x-4">
            <div className="p-3 bg-red-500 rounded-xl group-hover:scale-110 transition-transform">
              <Youtube className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="text-xl font-semibold text-white">Learning Channels</h3>
              <p className="text-gray-300">Best YouTube channels for each career</p>
            </div>
          </div>
        </button>

        <button
          onClick={() => onNavigate('ai-tools')}
          className="p-6 bg-violet-500/20 hover:bg-violet-500/30 rounded-2xl transition-all duration-300 text-left group"
        >
          <div className="flex items-center space-x-4">
            <div className="p-3 bg-violet-500 rounded-xl group-hover:scale-110 transition-transform">
              <Bot className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="text-xl font-semibold text-white">AI Learning Tools</h3>
              <p className="text-gray-300">AI-powered resources for students</p>
            </div>
          </div>
        </button>
      </div>

      {/* Tech Careers Grid */}
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-white mb-6">Tech Career Paths</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {techCareers.map((career) => {
            const IconComponent = career.icon;
            return (
              <button
                key={career.name}
                onClick={() => onCareerSelect(career.name)}
                className="group p-6 bg-white/10 backdrop-blur-lg rounded-2xl border border-white/20 hover:border-white/40 transition-all duration-300 text-left hover:transform hover:scale-105"
              >
                <div className="flex items-start space-x-4 mb-4">
                  <div className={`p-3 bg-gradient-to-br ${career.color} rounded-xl group-hover:scale-110 transition-transform`}>
                    <IconComponent className="w-6 h-6 text-white" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="text-lg font-semibold text-white">{career.name}</h3>
                      <span className="text-xs px-2 py-1 bg-white/20 rounded-full text-gray-300">
                        {career.category}
                      </span>
                    </div>
                    <p className="text-gray-300 text-sm leading-relaxed mb-3">{career.description}</p>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-gray-400">Difficulty:</span>
                    <span className={`text-xs px-2 py-1 rounded-full ${getDifficultyColor(career.difficulty)}`}>
                      {career.difficulty}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-gray-400">Duration:</span>
                    <span className="text-xs text-blue-400">{career.duration}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-gray-400">Earning:</span>
                    <span className="text-xs text-green-400 font-semibold">{career.earning}</span>
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Stats Section */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="p-6 bg-white/10 backdrop-blur-lg rounded-2xl border border-white/20">
          <div className="text-center">
            <div className="text-3xl font-bold text-blue-400 mb-2">9+</div>
            <div className="text-gray-300">Career Paths</div>
          </div>
        </div>
        <div className="p-6 bg-white/10 backdrop-blur-lg rounded-2xl border border-white/20">
          <div className="text-center">
            <div className="text-3xl font-bold text-green-400 mb-2">100+</div>
            <div className="text-gray-300">Learning Resources</div>
          </div>
        </div>
        <div className="p-6 bg-white/10 backdrop-blur-lg rounded-2xl border border-white/20">
          <div className="text-center">
            <div className="text-3xl font-bold text-purple-400 mb-2">15+</div>
            <div className="text-gray-300">AI Tools</div>
          </div>
        </div>
        <div className="p-6 bg-white/10 backdrop-blur-lg rounded-2xl border border-white/20">
          <div className="text-center">
            <div className="text-3xl font-bold text-yellow-400 mb-2">$180K</div>
            <div className="text-gray-300">Max Earning</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;